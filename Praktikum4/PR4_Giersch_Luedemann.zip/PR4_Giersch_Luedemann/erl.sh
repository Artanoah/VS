#!/bin/bash
/usr/local/erlang/OTP_17.1/bin/erl "$@"