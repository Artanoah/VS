#!/bin/bash
killall -e erl 
killall -e DataSource
killall -e beam
killall -e beam.smp
killall -e java